//
//  Device.swift
//  Studio Recall
//
//  Created by True Jackie on 8/28/25.
//

import SwiftUI

// MARK: - Device Type Enum
enum DeviceType: String, Codable, CaseIterable {
    case rack
    case series500
    
    var displayName: String {
        switch self {
        case .rack:
            return "Rack Gear"
        case .series500:
            return "500 Series Module"
        }
    }
}

enum RackWidth: Int, Codable, CaseIterable, Identifiable {
	case full  = 6
	case half  = 3
	case third = 2
	
	var id: Int { rawValue }
	var label: String {
		switch self {
			case .full: return "Full (19\")"
			case .half: return "Half (½)"
			case .third: return "Third (⅓)"
		}
	}
}

enum EarPolicy: String, Codable, CaseIterable {
	/// No additional ears. Use only rails/fillers inside the span.
	case none
	/// Full-width panel includes its own built-in ears (typical 1U).
	case builtIn
	/// Partial device that needs add-on ears when placed at a row edge.
	case needsAdapters
}

// MARK: - Device Model
struct Device: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var name: String

    var type: DeviceType        // Rack vs 500
    
    var controls: [Control] = []
    
    // Physical sizing
    var rackUnits: Int? = 1       // e.g., 1U, 2U
	var rackWidth: RackWidth = .full
    var slotWidth: Int? = nil       // e.g., 1 slot, 2 slots
	var earPolicy: EarPolicy = .none
	var earWidthInches: CGFloat = DeviceMetrics.wingWidth
    
    var isFiller: Bool = false  // true = blank panel
    
    var imageData: Data? = nil  // expects a PNG in asset catalog or file system
    
    var categories: [String] = []   // User-defined categories
    
    // Equatable
    static func == (lhs: Device, rhs: Device) -> Bool {
        lhs.id == rhs.id
    }
}

final class EditableDevice: ObservableObject, Identifiable {
    @Published var device: Device
    let id = UUID()
    
    init(device: Device) {
        self.device = device
    }
}

enum RackGrid {
	static let columnsPerRow = 6
}

struct DeviceMetrics {
	static let rackTotalWidth: CGFloat = 19.0	// Inches
	static let wingWidth: CGFloat = 0.75			// Inches
    /// Scale in pixels per inch (ppi)
    static func rackSize(units: Int, scale: CGFloat) -> CGSize {
        CGSize(
            width: 19 * scale,                   // standard rack width in inches
            height: CGFloat(units) * 1.75 * scale // 1U = 1.75 inches
        )
    }

    static func moduleSize(units: Int, scale: CGFloat) -> CGSize {
        CGSize(
            width: CGFloat(units) * 1.5 * scale,                   // module width in inches
            height: 3 * 1.75 * scale              // 3U tall (like Eurorack)
        )
    }
	
	static func slotSize(scale ppi: CGFloat) -> CGSize {
		// A *single column* “slot” width; height is 1U (your current per-U size)
		let oneU = rackSize(units: 1, scale: ppi)              // you already have this
		let columnW = oneU.width / CGFloat(RackGrid.columnsPerRow)
		return CGSize(width: columnW, height: oneU.height)     // 1 column × 1U
	}
	
	static func deviceFrame(rackWidth: RackWidth,
							rackUnits: Int,
							scale ppi: CGFloat,
							rowSpacing: CGFloat) -> CGSize
	{
		let base = slotSize(scale: ppi) // 1 column × 1U (no gaps)
		let cols = CGFloat(rackWidth.rawValue)
		let rows = CGFloat(max(1, rackUnits))
		
		let width  = base.width * cols
		let height = base.height * rows + rowSpacing * max(0, rows - 1)
		
		return CGSize(width: width, height: height)
	}
}

// MARK: - Physical widths (inches) and conversions
extension DeviceMetrics {
	/// Total width (inches) occupied by a span of a given rack width.
	/// Full spans the entire 19" rack width; half spans 9.5"; third spans 19/3.
	static func spanInches(for rackWidth: RackWidth) -> CGFloat {
		switch rackWidth {
			case .full:    return 19.0
			case .half:    return 19.0 / 2.0           // 9.5"
			case .third:   return 19.0 / 3.0           // ≈6.3333"
//			case .quarter: return 19.0 / 4.0
		}
	}
	
	/// Faceplate **body** widths (inches) for devices that ship without ears.
	/// (Full-width gear art usually already includes ears.)
	static func bodyInches(for rackWidth: RackWidth) -> CGFloat {
		switch rackWidth {
			case .full:  return 19.0            // treat as full already
			case .half:  return 8.5             // per your studio gear
			case .third: return 5.5
		}
	}
	
	// MARK: - Edge widths (ears + rails) inside the fixed span
	/// Computes ear (wing) widths and the remaining rails (fillers) to draw inside the span.
	static func edgeWidths(
		for rackWidth: RackWidth,
		externalLeft: Bool,
		externalRight: Bool,
		policy: EarPolicy
	) -> (leftWing: CGFloat, rightWing: CGFloat, leftRail: CGFloat, rightRail: CGFloat) {
		
		let span = spanInches(for: rackWidth)
		
		// Full width: draw built-in ears if requested; otherwise nothing fancy.
		if rackWidth == .full {
			switch policy {
				case .builtIn:
					return (wingWidth, wingWidth, 0, 0)
				case .needsAdapters, .none:
					return (0, 0, 0, 0)
			}
		}
		
		// Partials: add adapter ears at row edges if policy allows.
		var leftWing: CGFloat = 0
		var rightWing: CGFloat = 0
		if policy != .none {
			if externalLeft  { leftWing  = wingWidth }
			if externalRight { rightWing = wingWidth }
		}
		
		// Remaining space shows as inner rails/fillers (split symmetrically by default).
		let railsTotal = max(0, span - leftWing - rightWing)
		let leftRail   = railsTotal * 0.5
		let rightRail  = railsTotal - leftRail
		return (leftWing, rightWing, leftRail, rightRail)
	}
	
	static func totalWidth(for rackWidth: RackWidth, externalLeft: Bool, externalRight: Bool) -> CGFloat {
		// Alignment fix:
		// Devices occupy exactly their grid span width. Wings/rails render inside.
		return spanInches(for: rackWidth)
	}

	
	/// Convert inches → points using your scale (ppi).
	static func points(fromInches inches: CGFloat, ppi: CGFloat) -> CGFloat {
		inches * ppi
	}
}

extension DeviceMetrics {
	/// Total width in points for this device (body + external wings)
	static func totalPoints(
		rackWidth: RackWidth,
		rackUnits: Int,
		externalLeft: Bool,
		externalRight: Bool,
		ppi: CGFloat
	) -> CGSize {
		let inches = totalWidth(for: rackWidth,
								externalLeft: externalLeft,
								externalRight: externalRight)
		let widthPts  = inches * ppi
		let heightPts = CGFloat(rackUnits) * 1.75 * ppi
		return CGSize(width: widthPts, height: heightPts)
	}
}


