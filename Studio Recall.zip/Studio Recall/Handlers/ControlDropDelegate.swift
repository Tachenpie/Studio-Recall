//
//  ControlDropDelegate.swift
//  Studio Recall
//
//  Created by True Jackie on 9/4/25.
//
//
//import SwiftUI
//import UniformTypeIdentifiers
//
//struct ControlDropDelegate: DropDelegate {
//	
//}
