//
//  RackChassisSlotView.swift
//  Studio Recall
//
//  Created by True Jackie on 9/2/25.
//
import UniformTypeIdentifiers
import SwiftUI
import AppKit

struct RackChassisSlotView: View {
    let row: Int
	let col: Int
    let instance: DeviceInstance?
	
	private let wingWidth: CGFloat = 10
	private let railWidth: CGFloat = 12
	private let thinRailWidth: CGFloat = 4
	private let hoverRevealWidth: CGFloat = 12
	
    @Binding var slots: [[DeviceInstance?]]
    @EnvironmentObject var settings: AppSettings
    @EnvironmentObject var library: DeviceLibrary
	@EnvironmentObject var sessionManager: SessionManager
    
    @Binding var hoveredIndex: Int?
    @Binding var hoveredRange: Range<Int>?
    @Binding var hoveredValid: Bool
	
	@State private var railHover = false
	@State private var hoverLeft = false
	@State private var hoverRight = false
	@State private var editingDevice: Device?
	@State private var isPresentingEditor = false

    var body: some View {
        Group {
            if let instance, let device = library.device(for: instance.deviceID) {
                deviceView(device, instance: instance)
            } else {
//                emptySlotView()
				EmptyView()
            }
        }
    }

	// MARK: - Device view fills the parent cell/span size
//	private func deviceView(_ device: Device, instance: DeviceInstance) -> some View {
//		guard let anchor = anchorOfInstance(instance) else { return AnyView(EmptyView()) }
//		let instanceBinding = binding(for: device, instance: instance, at: anchor)
//		
//		let leftNeighbor  = hasLeftNeighbor(instance: instance, device: device, anchor: anchor)
//		let rightNeighbor = hasRightNeighbor(instance: instance, device: device, anchor: anchor)
//		
//		let externalLeft  = !leftNeighbor
//		let externalRight = !rightNeighbor
//		let isPartialWidth = (device.rackWidth != .full)
//		
//		let ppi = settings.pointsPerInch
//		
//		// Dynamic widths (points) for partial devices only
//		let widths = isPartialWidth
//		? edgeWidthsForPartial(width: device.rackWidth,
//							   externalLeft: externalLeft,
//							   externalRight: externalRight,
//							   ppi: ppi)
//		: (leftWingPt: 0, rightWingPt: 0, leftRailPt: 0, rightRailPt: 0)
//		
//		// Base content (faceplate + controls), padded only where a WING exists
//		let content =
//		GeometryReader { geo in
//			ZStack(alignment: .topLeading) {
//				DeviceView(device: device)
//					.frame(width: geo.size.width - widths.leftWingPt - widths.rightWingPt,
//						   height: geo.size.height)
//					.clipped()
//					.allowsHitTesting(false)
//				
//				RuntimeControlsOverlay(device: device, instance: instanceBinding)
//					.frame(width: geo.size.width - widths.leftWingPt - widths.rightWingPt,
//						   height: geo.size.height)
//					.zIndex(1)
//			}
//			.frame(width: geo.size.width, height: geo.size.height, alignment: .topLeading)
//		}
//		.overlay(
//			Rectangle()
//				.stroke(highlightColor(), lineWidth: 3)
//				.allowsHitTesting(false)
//		)
//		
//		// Compose with wings + rails (rails appear ONLY on hover)
//		let withEdges =
//		content
//		
//		// LEFT EDGE (wing + hover rail logic)
//			.overlay(alignment: .leading) {
//				ZStack(alignment: .leading) {
//					if isPartialWidth && externalLeft {
//						WingPlate().allowsHitTesting(false)
//							.frame(width: widths.leftWingPt)   // ensure wing matches computed width
//							.zIndex(0)
//					}
//					if hoverLeft {
//						if isPartialWidth && !externalLeft {
//							ThinRailOverlay(
//								width: max(1, widths.leftRailPt),   // a few points minimum when leftover is tiny
//								preview: {
//									DeviceView(device: device)
//										.frame(width: 220, height: 90)
//										.cornerRadius(8)
//										.shadow(radius: 8)
//								},
//								onDragProvider: { deviceDragProvider(instance: instance, device: device) },
//								onRemove: { removeInstance(instance, device: device) },
//								onEdit: { startEditing(device) }
//							)
//							.zIndex(1)
//						} else {
//							RailOverlay(
//								width: railWidth,
//								preview: {
//									DeviceView(device: device)
//										.frame(width: 220, height: 90)
//										.cornerRadius(8)
//										.shadow(radius: 8)
//								},
//								onDragProvider: { deviceDragProvider(instance: instance, device: device) },
//								onRemove: { removeInstance(instance, device: device) },
//								onEdit: { startEditing(device) }
//							)
//							.zIndex(1)
//						}
//					}
//				}
//			}
//
//		// RIGHT EDGE
//			.overlay(alignment: .trailing) {
//				ZStack(alignment: .trailing) {
//					if isPartialWidth && externalRight {
//						WingPlate().allowsHitTesting(false)
//							.frame(width: widths.rightWingPt)   // ensure wing matches computed width
//							.zIndex(0)
//					}
//					if hoverRight {
//						if isPartialWidth && !externalRight {
//							ThinRailOverlay(
//								width: max(1, widths.rightRailPt),   // a few points minimum when leftover is tiny
//								preview: {
//									DeviceView(device: device)
//										.frame(width: 220, height: 90)
//										.cornerRadius(8)
//										.shadow(radius: 8)
//								},
//								onDragProvider: { deviceDragProvider(instance: instance, device: device) },
//								onRemove: { removeInstance(instance, device: device) },
//								onEdit: { startEditing(device) }
//							)
//							.zIndex(1)
//						} else {
//							RailOverlay(
//								width: railWidth,
//								preview: {
//									DeviceView(device: device)
//										.frame(width: 220, height: 90)
//										.cornerRadius(8)
//										.shadow(radius: 8)
//								},
//								onDragProvider: { deviceDragProvider(instance: instance, device: device) },
//								onRemove: { removeInstance(instance, device: device) },
//								onEdit: { startEditing(device) }
//							)
//							.zIndex(1)
//						}
//					}
//				}
//			}
//		
//		// Invisible HOVER SENSORS (don’t block clicks/drags)
//			.overlay(alignment: .leading) {
//				Color.clear
//					.frame(width: hoverRevealWidth)
//					.contentShape(Rectangle())
//					.onHover { hoverLeft = $0 }
//			}
//			.overlay(alignment: .trailing) {
//				Color.clear
//					.frame(width: hoverRevealWidth)
//					.contentShape(Rectangle())
//					.onHover { hoverRight = $0 }
//			}
//		
//		// Per-device drop: only when NOT dragging this instance (so grid can receive the move)
//		let payload = DragContext.shared.currentPayload
//		let enableDeviceDrop = (payload?.instanceId == instance.id)  // ⟵ only when moving THIS instance
//		
//		if enableDeviceDrop {
//			return AnyView(
//				withEdges.onDrop(
//					of: [UTType.deviceDragPayload],
//					delegate: ChassisDropDelegate(
//						fixedCell: (anchor.row, anchor.col),   // keep anchor drop working
//						indexFor: nil,
//						slots: $slots,
//						hoveredIndex: $hoveredIndex,
//						hoveredValid: $hoveredValid,
//						hoveredRange: $hoveredRange,
//						library: library,
//						kind: .rack,
//						onCommit: { sessionManager.saveSessions() }
//					)
//				)
//			)
//		} else {
//			// No device-level drop; let the chassis/grid handle new-device drops or moves of other instances.
//			return AnyView(withEdges)
//		}
//	}
	private func deviceView(_ device: Device, instance: DeviceInstance) -> some View {
		guard let anchor = anchorOfInstance(instance) else { return AnyView(EmptyView()) }
		let instanceBinding = binding(for: device, instance: instance, at: anchor)
		
		let leftNeighbor  = hasLeftNeighbor(instance: instance, device: device, anchor: anchor)
		let rightNeighbor = hasRightNeighbor(instance: instance, device: device, anchor: anchor)
		
		let externalLeft  = !leftNeighbor
		let externalRight = !rightNeighbor
		let isPartialWidth = (device.rackWidth != .full)
		
		let ppi = settings.pointsPerInch
		
		// === Compute actual physical sizes ===
		let bodyInches: CGFloat = DeviceMetrics.bodyInches(for: device.rackWidth)
		
		let wingInches: CGFloat = (device.rackWidth == .full) ? 0 : DeviceMetrics.wingWidth
		
		let bodyPts  = bodyInches * ppi
		let wingPts  = wingInches * ppi
		let faceH    = DeviceMetrics.rackSize(units: device.rackUnits ?? 1, scale: ppi).height
		
		// Total width for this device = body + wings if external
		let totalW: CGFloat = bodyPts
		+ (externalLeft  ? wingPts : 0)
		+ (externalRight ? wingPts : 0)
		
		// === Content (faceplate + overlay), offset by left wing if present ===
		let content =
		ZStack(alignment: .topLeading) {
			// LEFT WING
			if isPartialWidth && externalLeft {
				WingPlate()
					.frame(width: wingPts, height: faceH)
					.allowsHitTesting(false)
					.zIndex(0)
			}
			
			// FACE + CONTROLS
			ZStack(alignment: .topLeading) {
				DeviceView(device: device)
					.frame(width: bodyPts, height: faceH)
					.clipped()
					.allowsHitTesting(false)
				
				RuntimeControlsOverlay(device: device, instance: instanceBinding)
					.frame(width: bodyPts, height: faceH)
					.zIndex(1)
			}
			.offset(x: externalLeft ? wingPts : 0)
			
			// RIGHT WING
			if isPartialWidth && externalRight {
				WingPlate()
					.frame(width: wingPts, height: faceH)
					.allowsHitTesting(false)
					.offset(x: externalLeft ? (wingPts + bodyPts) : bodyPts)
					.zIndex(0)
			}
		}
		.frame(width: totalW, height: faceH, alignment: .topLeading)
		.overlay(
			Rectangle()
				.stroke(highlightColor(), lineWidth: 3)
				.allowsHitTesting(false)
		)
		
		// === Hover rails and drop handling stay the same ===
		let withEdges =
		content
		// LEFT EDGE hover overlays
			.overlay(alignment: .leading) {
				ZStack(alignment: .leading) {
					if hoverLeft {
						if isPartialWidth && !externalLeft {
							ThinRailOverlay(
								width: max(1, wingPts),
								preview: {
									DeviceView(device: device)
										.frame(width: 220, height: 90)
										.cornerRadius(8)
										.shadow(radius: 8)
								},
								onDragProvider: { deviceDragProvider(instance: instance, device: device) },
								onRemove: { removeInstance(instance, device: device) },
								onEdit: { startEditing(device) }
							)
							.zIndex(1)
						} else {
							RailOverlay(
								width: railWidth,
								preview: {
									DeviceView(device: device)
										.frame(width: 220, height: 90)
										.cornerRadius(8)
										.shadow(radius: 8)
								},
								onDragProvider: { deviceDragProvider(instance: instance, device: device) },
								onRemove: { removeInstance(instance, device: device) },
								onEdit: { startEditing(device) }
							)
							.zIndex(1)
						}
					}
				}
			}
		// RIGHT EDGE hover overlays
			.overlay(alignment: .trailing) {
				ZStack(alignment: .trailing) {
					if hoverRight {
						if isPartialWidth && !externalRight {
							ThinRailOverlay(
								width: max(1, wingPts),
								preview: {
									DeviceView(device: device)
										.frame(width: 220, height: 90)
										.cornerRadius(8)
										.shadow(radius: 8)
								},
								onDragProvider: { deviceDragProvider(instance: instance, device: device) },
								onRemove: { removeInstance(instance, device: device) },
								onEdit: { startEditing(device) }
							)
							.zIndex(1)
						} else {
							RailOverlay(
								width: railWidth,
								preview: {
									DeviceView(device: device)
										.frame(width: 220, height: 90)
										.cornerRadius(8)
										.shadow(radius: 8)
								},
								onDragProvider: { deviceDragProvider(instance: instance, device: device) },
								onRemove: { removeInstance(instance, device: device) },
								onEdit: { startEditing(device) }
							)
							.zIndex(1)
						}
					}
				}
			}
		// Invisible hover sensors
			.overlay(alignment: .leading) {
				Color.clear
					.frame(width: hoverRevealWidth)
					.contentShape(Rectangle())
					.onHover { hoverLeft = $0 }
			}
			.overlay(alignment: .trailing) {
				Color.clear
					.frame(width: hoverRevealWidth)
					.contentShape(Rectangle())
					.onHover { hoverRight = $0 }
			}
		
		// === Per-device drop (unchanged) ===
		let payload = DragContext.shared.currentPayload
		let enableDeviceDrop = (payload?.instanceId == instance.id)
		
		if enableDeviceDrop {
			return AnyView(
				withEdges.onDrop(
					of: [UTType.deviceDragPayload],
					delegate: ChassisDropDelegate(
						fixedCell: (anchor.row, anchor.col),
						indexFor: nil,
						slots: $slots,
						hoveredIndex: $hoveredIndex,
						hoveredValid: $hoveredValid,
						hoveredRange: $hoveredRange,
						library: library,
						kind: .rack,
						onCommit: { sessionManager.saveSessions() }
					)
				)
			)
		} else {
			return AnyView(withEdges)
		}
	}



	
	// MARK: - Helpers
	
	private func spanRows(of device: Device) -> Int { max(1, device.rackUnits ?? 1) }
	private func spanCols(of device: Device) -> Int { max(1, device.rackWidth.rawValue) }
	
	private func allocateEdges(
		avail: CGFloat,
		isPartial: Bool,
		externalLeft: Bool,
		externalRight: Bool,
		oneInch: CGFloat
	) -> (wingL: CGFloat, wingR: CGFloat, railL: CGFloat, railR: CGFloat) {
		var wingL: CGFloat = 0, wingR: CGFloat = 0, railL: CGFloat = 0, railR: CGFloat = 0
		
		if isPartial {
			switch (externalLeft, externalRight) {
				case (false, false):                // both internal
					railL = avail * 0.5
					railR = avail - railL
				case (true,  false):                // left external only
					wingL = min(oneInch, avail)
					railR = avail - wingL
				case (false, true):                 // right external only
					wingR = min(oneInch, avail)
					railL = avail - wingR
				case (true,  true):                 // both external
					wingL = min(oneInch, avail * 0.5)
					wingR = min(oneInch, avail - wingL)
			}
		} else {
			// full-width: everything is rails (no wings)
			railL = avail * 0.5
			railR = avail - railL
		}
		
		return (wingL, wingR, railL, railR)
	}

	// Binds an instance so writes fan out across the full span of this device.
	private func binding(for device: Device,
						 instance: DeviceInstance,
						 at anchor: (row: Int, col: Int)) -> Binding<DeviceInstance> {
		Binding<DeviceInstance>(
			get: { slots[anchor.row][anchor.col]! },
			set: { newVal in
				let rows = spanRows(of: device)
				let cols = spanCols(of: device)
				for r in anchor.row ..< min(anchor.row + rows, slots.count) {
					for c in anchor.col ..< min(anchor.col + cols, RackGrid.columnsPerRow) {
						slots[r][c] = newVal
					}
				}
			}
		)
	}

	private func anchorOfInstance(_ instance: DeviceInstance) -> (row: Int, col: Int)? {
		for r in slots.indices {
			for c in 0..<RackGrid.columnsPerRow {
				if slots[r][c]?.id == instance.id {
					let isTop = (r == 0) || (slots[r-1][c]?.id != instance.id)
					let isLeft = (c == 0) || (slots[r][c-1]?.id != instance.id)
					if isTop && isLeft { return (r,c) }
				}
			}
		}
		return nil
	}
	
	private func highlightColor() -> Color {
		if let range = hoveredRange, range.contains(row) {
			return hoveredValid ? .green : .red
		}
		return .clear
	}
	
	private func deviceDragProvider(instance: DeviceInstance, device: Device) -> NSItemProvider {
		let payload = DragPayload(instanceId: instance.id, deviceId: device.id)
		DragContext.shared.beginDrag(payload: payload)
		let provider = NSItemProvider()
		provider.registerDataRepresentation(forTypeIdentifier: UTType.deviceDragPayload.identifier,
											visibility: .all) { completion in
			completion(try? JSONEncoder().encode(payload), nil)
			return nil
		}
		return provider
	}
	
	private func removeInstance(_ instance: DeviceInstance, device: Device) {
		if let anchor = anchorOfInstance(instance) {
			for r in anchor.row ..< min(anchor.row + spanRows(of: device), slots.count) {
				for c in anchor.col ..< min(anchor.col + spanCols(of: device), RackGrid.columnsPerRow) {
					slots[r][c] = nil
				}
			}
		}
	}
	
	private func startEditing(_ device: Device) {
		editingDevice = device
		isPresentingEditor = true
	}
	
	/// Is there a different instance immediately left of this device span on ANY row it occupies?
	private func hasLeftNeighbor(instance: DeviceInstance, device: Device, anchor: (row: Int, col: Int)) -> Bool {
		guard anchor.col > 0 else { return false }
		let rows = spanRows(of: device)
		for r in anchor.row..<min(anchor.row + rows, slots.count) {
			if let left = slots[r][anchor.col - 1], left.id != instance.id { return true }
		}
		return false
	}
	
	/// Is there a different instance immediately right of this device span on ANY row it occupies?
	private func hasRightNeighbor(instance: DeviceInstance, device: Device, anchor: (row: Int, col: Int)) -> Bool {
		let cols = spanCols(of: device)
		let rightCol = anchor.col + cols
		guard rightCol < RackGrid.columnsPerRow else { return false }
		let rows = spanRows(of: device)
		for r in anchor.row..<min(anchor.row + rows, slots.count) {
			if let right = slots[r][rightCol], right.id != instance.id { return true }
		}
		return false
	}
	
	/// Given a rack width and neighbor flags, return wing/rail widths (points) for each side.
	/// External sides get up to 1.0" wings (capped by leftover), internal sides share the remainder as thin rails.
	/// For thirds: leftover is ≈0.8333" total; external wing becomes ≤0.8333" (so no overhang), internal sides get the rest.
	private func edgeWidthsForPartial(
		width: RackWidth,
		externalLeft: Bool,
		externalRight: Bool,
		ppi: CGFloat
	) -> (leftWingPt: CGFloat, rightWingPt: CGFloat, leftRailPt: CGFloat, rightRailPt: CGFloat) {
		
		let spanIn  = DeviceMetrics.spanInches(for: width)
		let bodyIn  = DeviceMetrics.bodyInches(for: width)
		var leftOver = max(0, spanIn - bodyIn)          // total inches to distribute
		
		// External sides try to take up to 1.0" each, but never exceed leftover.
		var leftWingIn:  CGFloat = 0
		var rightWingIn: CGFloat = 0
		if externalLeft  { let take = min(1.0, leftOver); leftWingIn  = take; leftOver -= take }
		if externalRight { let take = min(1.0, leftOver); rightWingIn = take; leftOver -= take }
		
		// Whatever remains becomes thin internal rails.
		// If both sides are internal, split evenly so seams look symmetric.
		var leftRailIn:  CGFloat = 0
		var rightRailIn: CGFloat = 0
		if !externalLeft && !externalRight {
			leftRailIn = leftOver / 2.0
			rightRailIn = leftOver - leftRailIn
		} else if !externalLeft {
			leftRailIn = leftOver
			rightRailIn = 0
		} else if !externalRight {
			rightRailIn = leftOver
			leftRailIn = 0
		} // else: both external; nothing left
		
		// Convert to points
		return (
			DeviceMetrics.points(fromInches: leftWingIn,  ppi: ppi),
			DeviceMetrics.points(fromInches: rightWingIn, ppi: ppi),
			DeviceMetrics.points(fromInches: leftRailIn,  ppi: ppi),
			DeviceMetrics.points(fromInches: rightRailIn, ppi: ppi)
		)
	}

	// MARK: - Rails
	
	@ViewBuilder
	private func RailEdge(_ alignment: Alignment, instance: DeviceInstance, device: Device) -> some View {
		let edge: HorizontalAlignment = (alignment == .leading ? .leading : .trailing)
		Rectangle()
			.fill(.ultraThinMaterial)
			.overlay(Rectangle().stroke(.secondary.opacity(0.35), lineWidth: 1))
			.frame(width: 12)
			.opacity(0.9)
			.help("Drag to move this device")
			.overlay(RailScrewsV())
			.contentShape(Rectangle())
			.onDrag {
				deviceDragProvider(instance: instance, device: device)
			} preview: {
				DeviceView(device: device)
					.frame(width: 140, height: 60)
					.shadow(radius: 6)
			}
			.contextMenu {
				Button("Edit Device...") {
					editingDevice = device
					isPresentingEditor = true
				}
				Button("Remove from rack", role: .destructive) {
					// clear the whole span
					if let anchor = anchorOfInstance(instance) {
						for r in anchor.row ..< min(anchor.row + spanRows(of: device), slots.count) {
							for c in anchor.col ..< min(anchor.col + spanCols(of: device), RackGrid.columnsPerRow) {
								slots[r][c] = nil
							}
						}
					}
				}
			}
			.frame(maxHeight: .infinity, alignment: alignment)
			.alignmentGuide(edge) { d in d[edge] }
			.overlay(alignment: alignment) { Color.clear.frame(width: 0, height: 0) } // keep alignment
	}
	
	private struct RailOverlay<Preview: View>: View {
		let width: CGFloat
		let preview: () -> Preview
		let onDragProvider: () -> NSItemProvider
		let onRemove: () -> Void
		let onEdit: () -> Void
		
		var body: some View {
			Rectangle()
				.fill(.ultraThinMaterial)
				.overlay(Rectangle().stroke(.secondary.opacity(0.35), lineWidth: 1))
				.frame(width: width)
				.opacity(0.9)
				.help("Drag to move this device. Right-click to edit or remove.")
				.overlay(RailScrewsV())
				.contentShape(Rectangle())
				.onDrag { onDragProvider() } preview: { preview() }
				.contextMenu {
					Button("Edit Device…") { onEdit() }
					Button("Remove from rack", role: .destructive) { onRemove() }
				}
		}
	}

	private struct ThinRailOverlay<Preview: View>: View {
		let width: CGFloat
		let preview: () -> Preview
		let onDragProvider: () -> NSItemProvider
		let onRemove: () -> Void
		let onEdit: () -> Void
		
		var body: some View {
			Rectangle()
				.fill(.ultraThinMaterial)
				.overlay(Rectangle().stroke(.secondary.opacity(0.25), lineWidth: 0.5))
				.frame(width: width)
				.opacity(0.9)
//				.overlay(RailScrewsV().opacity(0.3))   // optional tiny screws
				.help("Drag to move this device. Right-click to edit or remove.")
				.contentShape(Rectangle())
				.onDrag { onDragProvider() } preview: { preview() }
				.contextMenu {
					Button("Edit Device…") { onEdit() }
					Button("Remove from rack", role: .destructive) { onRemove() }
				}
		}
	}
	
	private struct RailScrewsV: View {
		var body: some View {
			VStack {
				Circle().fill(.secondary).frame(width: 4, height: 4)
				Spacer()
				Circle().fill(.secondary).frame(width: 4, height: 4)
			}
			.padding(.vertical, 6)
		}
	}
	
	private struct WingPlate: View {
		var body: some View {
			ZStack {
				RoundedRectangle(cornerRadius: 2)
					.fill(LinearGradient(
						colors: [
							Color(nsColor: .windowBackgroundColor).opacity(0.85),
							Color.black.opacity(0.10)
						],
						startPoint: .topLeading, endPoint: .bottomTrailing
					))
					.overlay(
						RoundedRectangle(cornerRadius: 2)
							.stroke(Color.black.opacity(0.25), lineWidth: 0.5)
					)
				VStack {
					Circle().fill(Color.black.opacity(0.35)).frame(width: 3, height: 3)
					Spacer()
					Circle().fill(Color.black.opacity(0.35)).frame(width: 3, height: 3)
				}
				.padding(.vertical, 6)
			}
			// WIDTH IS PROVIDED BY CALLER NOW (.frame(width: widths.leftWingPt/rightWingPt))
			.compositingGroup()     // keeps both sides visually identical
		}
	}
}
