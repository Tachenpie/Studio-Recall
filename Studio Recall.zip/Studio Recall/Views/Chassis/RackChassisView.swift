//
//  RackChassisView.swift
//  Studio Recall
//
//  Created by True Jackie on 8/28/25.
//
import UniformTypeIdentifiers
import SwiftUI

struct RackChassisView: View {
    @Binding var rack: Rack
    @EnvironmentObject var settings: AppSettings
    @EnvironmentObject var library: DeviceLibrary
	@EnvironmentObject var sessionManager: SessionManager
	
	@Environment(\.canvasZoom) private var canvasZoom
    
    @State private var hoveredIndex: Int? = nil
    @State private var hoveredValid: Bool = false
    @State private var hoveredRange: Range<Int>? = nil
	@State private var dragStart: CGPoint? = nil
	@State private var showEdit = false
	@State private var editUnits: Int = 0
	
	var onDelete: (() -> Void)? = nil
    
	private let rowSpacing: CGFloat = 1      // between U rows in the VStack
	private let facePadding: CGFloat = 16    // .padding() around the chassis face

	var body: some View {
		let oneU = DeviceMetrics.rackSize(units: 1, scale: settings.pointsPerInch)
		// Face padding is .padding() on the face = 16pt per side -> +32
		let faceWidth = oneU.width + 32
		
		VStack(spacing: 0) {
			// 1) TABLETOP (not a drop target)
			DragStrip(
				title: (rack.name?.isEmpty == false ? rack.name : "Rack"),
				onBegan: { if dragStart == nil { dragStart = rack.position } },
				onDrag: { screenDelta in
					let origin = dragStart ?? rack.position
					let z = max(canvasZoom, 0.0001)                   // @Environment(\.canvasZoom)
					let worldDelta = CGSize(width: screenDelta.width  / z,
											height: screenDelta.height / z)
					rack.position = CGPoint(x: origin.x + worldDelta.width,
											y: origin.y + worldDelta.height)
				},
				onEnded: { dragStart = nil },
				onEditRequested: {
					editUnits = max(1, rack.rows)
					showEdit = true
				},
				onClearRequested: {
					clearAllRackDevices()
				},
				onDeleteRequested: {
					onDelete?()
				}
			)
			.frame(width: faceWidth)            // <<< exact match
			.zIndex(2)
			// --- 2) CHASSIS FACE (fixed height; no GeometryReader) ---
			let oneU = DeviceMetrics.rackSize(units: 1, scale: settings.pointsPerInch) // ✅ full 19" × 1U
			let innerW = oneU.width                               // full rack inner width (points)
			let colW   = innerW / CGFloat(RackGrid.columnsPerRow) // width per column
			let rowH   = oneU.height                               // height per U
			
			let faceWidth  = innerW + facePadding * 2
			let faceHeight = facePadding * 2 + CGFloat(rack.rows) * rowH + rowSpacing * CGFloat(max(0, rack.rows - 1))
			
			ZStack(alignment: .topLeading) {
				
				// A) GRID (empty-cell drop targets)
				VStack(spacing: rowSpacing) {
					ForEach(0..<rack.rows, id: \.self) { r in
						HStack(spacing: 0) {
							ForEach(0..<RackGrid.columnsPerRow, id: \.self) { c in
								if rack.slots[r][c] == nil {
									Rectangle()
										.fill(Color.white.opacity(0.06))
										.overlay(
											Rectangle().stroke(Color.secondary.opacity(0.6),
															   style: StrokeStyle(lineWidth: 1, dash: [4]))
										)
										.contentShape(Rectangle())
										.onDrop(of: [UTType.deviceDragPayload],
												delegate: ChassisDropDelegate(
													fixedCell: (r, c),
													indexFor: nil,
													slots: $rack.slots,
													hoveredIndex: $hoveredIndex,
													hoveredValid: $hoveredValid,
													hoveredRange: $hoveredRange,
													library: library,
													kind: .rack,
													onCommit: { sessionManager.saveSessions() }
												))
								} else {
									Color.clear.allowsHitTesting(false)
								}
							}
						}
						.frame(height: rowH)
					}
				}
				.frame(width: innerW)
				.padding(facePadding)
				
//				// B) DEVICES OVERLAYED AT ABSOLUTE TOP-LEFT POSITIONS
//				ForEach(anchors(), id: \.instance.id) { anchor in
//					let cols = CGFloat(anchor.device.rackWidth.rawValue)
//					let rows = CGFloat(max(1, anchor.device.rackUnits ?? 1))
//					let size = CGSize(
//						width:  colW * cols,
//						height: rowH * rows + rowSpacing * max(0, rows - 1)
//					)
//					let x = facePadding + CGFloat(anchor.col) * colW
//					let y = facePadding + CGFloat(anchor.row) * (rowH + rowSpacing)
//					
//					RackChassisSlotView(
//						row: anchor.row,
//						col: anchor.col,
//						instance: anchor.instance,
//						slots: $rack.slots,
//						hoveredIndex: $hoveredIndex,
//						hoveredRange: $hoveredRange,
//						hoveredValid: $hoveredValid
//					)
//					.frame(width: size.width, height: size.height, alignment: .topLeading)
//					.position(x: x + size.width / 2, y: y + size.height / 2)
//				}
				// B) DEVICES OVERLAYED AT ABSOLUTE TOP-LEFT POSITIONS (inch-based)
				ForEach(anchors(), id: \.instance.id) { anchor in
					let device = anchor.device
					let units  = device.rackUnits ?? 1
					
					// External edges for rendering (neighbor info is already correct in anchors)
					let rowSlots = rack.slots[anchor.row]
					let colIndex = rowSlots.firstIndex(where: { $0?.id == anchor.instance.id }) ?? 0
					let leftNeighbor  = (colIndex > 0) ? rowSlots[colIndex - 1] : nil
					let rightNeighbor = (colIndex < rowSlots.count - 1) ? rowSlots[colIndex + 1] : nil
					let externalLeft  = (leftNeighbor == nil)
					let externalRight = (rightNeighbor == nil)
					
					let sizePts = DeviceMetrics.totalPoints(
						rackWidth: device.rackWidth,
						rackUnits: units,
						externalLeft: externalLeft,
						externalRight: externalRight,
						ppi: settings.pointsPerInch
					)
					
					let xPts = facePadding + anchor.xInches * settings.pointsPerInch
					let yPts = facePadding + CGFloat(anchor.row) * (rowH + rowSpacing)
					
					RackChassisSlotView(
						row: anchor.row,
						col: colIndex,
						instance: anchor.instance,
						slots: $rack.slots,
						hoveredIndex: $hoveredIndex,
						hoveredRange: $hoveredRange,
						hoveredValid: $hoveredValid
					)
					.frame(width: sizePts.width, height: sizePts.height, alignment: .topLeading)
					.position(x: xPts + sizePts.width / 2, y: yPts + sizePts.height / 2)
				}

			}
			// Make the *whole face* droppable so new devices land even if user misses a cell
			.contentShape(Rectangle())
			.frame(width: faceWidth, height: faceHeight)
			.background(Color.black.opacity(0.8))
			.cornerRadius(8)
			.overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.gray.opacity(0.85), lineWidth: 1))
			.allowsHitTesting(true)
			.onDrop(
				of: [UTType.deviceDragPayload, .item, .data, .plainText, .utf8PlainText],
				delegate: ChassisDropDelegate(
					fixedCell: nil,
					indexFor: { pt in cellIndex(for: pt, colW: colW, rowH: rowH) },
					slots: $rack.slots,
					hoveredIndex: $hoveredIndex,
					hoveredValid: $hoveredValid,
					hoveredRange: $hoveredRange,
					library: library,
					kind: .rack,
					onCommit: {
						sessionManager.saveSessions()
						DragContext.shared.endDrag()
					}
				)
				)
			.zIndex(1)
		}
		.sheet(isPresented: $showEdit) { editSheet }
	}
    
	// MARK: - Inch-aware cellView
	private func cellView(row: Int, col: Int) -> some View {
		if let inst = rack.slots[row][col],
		   let device = library.device(for: inst.deviceID) {
			// Occupied slot → show the device
			return AnyView(
				RackChassisSlotView(
					row: row,
					col: col,
					instance: inst,
					slots: $rack.slots,
					hoveredIndex: $hoveredIndex,
					hoveredRange: $hoveredRange,
					hoveredValid: $hoveredValid
				)
			)
		} else {
			// Empty placeholder slot
			let oneU   = DeviceMetrics.rackSize(units: 1, scale: settings.pointsPerInch)
			let cellW  = (19.0 / 6.0) * settings.pointsPerInch  // nominal column width
			let cellH  = oneU.height
			
			return AnyView(
				Rectangle()
					.fill(Color.white.opacity(0.03))
					.frame(width: cellW, height: cellH)
					.overlay(
						Rectangle()
							.stroke(Color.secondary.opacity(0.6),
									style: StrokeStyle(lineWidth: 1, dash: [4]))
					)
					.contentShape(Rectangle())
			)
		}
	}


	private func emptySlotView(units: Int = 1) -> some View {
		let oneU   = DeviceMetrics.rackSize(units: units, scale: settings.pointsPerInch)
		let cellW  = (19.0 / 6.0) * settings.pointsPerInch
		let cellH  = oneU.height
		
		return Rectangle()
			.fill(Color.white.opacity(0.03))
			.frame(width: cellW, height: cellH)
			.overlay(
				Rectangle()
					.stroke(Color.secondary.opacity(0.6), style: StrokeStyle(lineWidth: 1, dash: [4]))
			)
			.contentShape(Rectangle())
	}

	// MARK: - Rack edit / helpers
	
	private func isTopLeftAnchor(_ inst: DeviceInstance, at pos: (Int, Int)) -> Bool {
		let (r, c) = pos
		if r > 0, rack.slots[r - 1][c]?.id == inst.id { return false }
		if c > 0, rack.slots[r][c - 1]?.id == inst.id { return false }
		return true
	}
	
	// Map a drop point to TOP-LEFT cell using measured sizes
	private func cellIndex(for pt: CGPoint, colW: CGFloat, rowH: CGFloat) -> (row: Int, col: Int) {
		// Dimensions must match how the face is drawn
		let faceHeight = facePadding * 2
		+ CGFloat(rack.rows) * rowH
		+ rowSpacing * CGFloat(max(0, rack.rows - 1))
		
		// Convert SwiftUI/macOS (bottom-left) -> our grid’s top-left
		let xFromLeft = max(0, pt.x - facePadding)
		let yFromTop  = max(0, faceHeight - pt.y - facePadding)
		
		let col = min(RackGrid.columnsPerRow - 1, max(0, Int(floor(xFromLeft / colW))))
		let row = min(rack.rows - 1,          max(0, Int(floor(yFromTop  / (rowH + rowSpacing)))))
		
		return (row, col)
	}

	
	// Return all anchor cells (top-left) with their instances & devices
	// MARK: - Inch-based anchors (x offset in INCHES from left edge)
	private func anchors() -> [(row: Int, xInches: CGFloat, device: Device, instance: DeviceInstance)] {
		var out: [(Int, CGFloat, Device, DeviceInstance)] = []
		
		for row in rack.slots.indices {
			var xInches: CGFloat = 0
			
			for col in rack.slots[row].indices {
				if let inst = rack.slots[row][col],
				   let dev = library.device(for: inst.deviceID) {
					
					// Determine external edges for this occupied span
					let leftNeighbor  = (col > 0) ? rack.slots[row][col - 1] : nil
					let rightNeighbor = (col < rack.slots[row].count - 1) ? rack.slots[row][col + 1] : nil
					let externalLeft  = (leftNeighbor == nil)
					let externalRight = (rightNeighbor == nil)
					
					// Anchor BEFORE we advance x
					out.append((row, xInches, dev, inst))
					
					// Advance by this device's total inches (body + wings if external)
					xInches += DeviceMetrics.spanInches(for: dev.rackWidth)
					
					// Skip over any cells this instance spans in your logical grid
					// (your slots already mark the same instance in each covered col)
				} else {
					// Empty logical cell: add a nominal column (keeps drop grid usable)
					xInches += 19.0 / 6.0
				}
			}
		}
		return out
	}


	
	private func clearAllRackDevices() {
		for r in rack.slots.indices {
			for c in 0..<RackGrid.columnsPerRow {
				rack.slots[r][c] = nil
			}
		}
	}
	
	@ViewBuilder
	private var editSheet: some View {
		VStack(alignment: .leading, spacing: 12) {
			Text("Edit Rack").font(.headline)
			Stepper("Rack Units: \(rack.rows)", value: Binding(
				get: { rack.rows },
				set: { applyRackResize(to: $0) }
			), in: 1...200)
			HStack {
				Spacer()
				Button("Close") { showEdit = false }
			}
		}
		.padding(20)
		.frame(width: 320)
	}
	
	private func applyRackResize(to newRows: Int) {
		guard newRows != rack.rows else { return }
		if newRows < rack.rows {
			rack.slots = Array(rack.slots.prefix(newRows))
		} else {
			let extra = Array(
				repeating: Array<DeviceInstance?>(repeating: nil, count: RackGrid.columnsPerRow),
				count: newRows - rack.rows
			)
			rack.slots.append(contentsOf: extra)
		}
		rack.rows = newRows
	}
}



