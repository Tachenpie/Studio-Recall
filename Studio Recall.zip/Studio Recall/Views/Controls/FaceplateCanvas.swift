//
//  FaceplateCanvas.swift
//  Studio Recall
//
//  Created by True Jackie on 8/28/25.
//
// FaceplateCanvas.swift
import SwiftUI
#if os(macOS)
import AppKit
#endif

struct FaceplateCanvas: View {
	@ObservedObject var editableDevice: EditableDevice
	@Environment(\.undoManager) private var undoManager
	@Environment(\.isPanMode) private var isPanMode
	
	// Selection / region edit
	@Binding var selectedControlId: UUID?
	@Binding var isEditingRegion: Bool
	@Binding var activeRegionIndex: Int
	@Binding var zoom: CGFloat
	@Binding var pan: CGSize
	// Optional external overlay (parent-space), e.g. detection boxes.
	// Signature matches CanvasViewport.overlayContent.
	var externalOverlay: ((CGSize /*parent*/, CGSize /*canvas*/, CGFloat /*zoom*/, CGSize /*pan*/) -> AnyView)? = nil
	
	// local state just for canvas content
	@State private var draggingControlId: UUID? = nil
	
	// tuning
	private let gridStep: CGFloat = 0.0025
	private let minRegion: CGFloat = 0.004
	
	var body: some View {
		let aspect = computeAspectRatio()
		let showBadges = !(isEditingRegion || draggingControlId != nil)
		
		CanvasViewport(
			aspect: aspect,
			zoom: $zoom,
			pan: $pan,
			content: { canvasSize in
				ZStack {
					CanvasContent(
						editableDevice: editableDevice,
						canvasSize: canvasSize,
						selectedControlId: $selectedControlId,
						draggingControlId: $draggingControlId,
						gridStep: gridStep,
						showBadges: showBadges
					)
					
					// Live preview of control patches (rotate/translate/flip/sprites) in the editor
					let faceplate = editableDevice.device.imageData.flatMap { NSImage(data: $0) }
					
					ForEach(editableDevice.device.controls.indices, id: \.self) { i in
						let control = editableDevice.device.controls[i]
						
						ForEach(Array(control.regions.enumerated()), id: \.0) { idx, region in
							ControlImageRenderer(
								control: $editableDevice.device.controls[i],
								faceplate: faceplate,
								canvasSize: canvasSize,
								resolveControl: { id in
									editableDevice.device.controls.first(where: { $0.id == id })
								},
								onlyRegionIndex: idx
							)
//							.frame(
//								width:  region.rect.width  * canvasSize.width,
//								height: region.rect.height * canvasSize.height
//							)
//							.position(
//								x: region.rect.midX * canvasSize.width,
//								y: region.rect.midY * canvasSize.height
//							)
							.compositingGroup()
							.mask { RegionClipShape(shape: region.shape) }
							.allowsHitTesting(false)
							.id(editableDevice.device.controls[i].renderKey)
						}
					}
					
					// Visual-only overlay stays in canvas space
					if let sel = selectedControlBinding, isEditingRegion {
						ForEach(sel.wrappedValue.regions.indices, id: \.self) { idx in
							RegionOverlay(
								rect: Binding(
									get: { sel.wrappedValue.regions[idx].rect },
									set: { updateRegionRect(of: sel, to: $0, idx: idx) }
								),
								canvasSize: canvasSize,
								gridStep: gridStep,
								minRegion: minRegion,
								shape: sel.wrappedValue.regions[idx].shape,
								zoom: zoom,
								controlType: sel.wrappedValue.type,
								regionIndex: idx,
								regions: sel.wrappedValue.regions
							)
						}
					}
				}
			},
			// Type-erase the overlay to AnyView so both branches match
			overlayContent: { parentSize, canvasSize, zoom, pan -> AnyView in
				AnyView(
					ZStack(alignment: .topLeading) {
						// Existing region edit overlay (unchanged)
						if let sel = selectedControlBinding, isEditingRegion {
							ForEach(sel.wrappedValue.regions.indices, id: \.self) { idx in
								RegionHitLayer(
									rect: Binding(
										get: { sel.wrappedValue.regions[idx].rect },
										set: { updateRegionRect(of: sel, to: $0, idx: idx) }
									),
									parentSize: parentSize,
									canvasSize: canvasSize,
									zoom: zoom,
									pan: pan,
									isPanMode: isPanMode,
									shape: sel.wrappedValue.regions[idx].shape,
									controlType: sel.wrappedValue.type,
									regionIndex: idx,
									regions: sel.wrappedValue.regions,
									isEnabled: activeRegionIndex == idx
								)
							}
						}
						
						// NEW: external overlay (e.g. detection boxes) in parent-space
						if let externalOverlay {
							externalOverlay(parentSize, canvasSize, zoom, pan)
						}
					}
				)
			},
			onDropString: { raw, localPoint, canvasSize in
				guard let type = ControlType(rawValue: raw) else { return false }
				let relX = max(0, min(1, localPoint.x / canvasSize.width))
				let relY = max(0, min(1, localPoint.y / canvasSize.height))
				let c = Control(name: type.displayName, type: type, x: relX, y: relY)
	
				// no snapping here
				editableDevice.device.controls.append(c)
				selectedControlId = c.id
				return true
			}
		)
		.environment(\.isRegionEditing, isEditingRegion)
		.onChange(of: selectedControlId) { _, newId in
			if let id = newId,
			   let idx = editableDevice.device.controls.firstIndex(where: { $0.id == id }) {
				editableDevice.device.controls[idx].ensureConcentricRegions()
			}
		}

#if os(macOS)
		.overlay(
			KeyCaptureLayer(
				selectedControlBinding: selectedControlBinding,
				isEditingRegion: isEditingRegion,
				coarseStep: gridStep,
				fineStep: gridStep / 2
			)
			.allowsHitTesting(false)
		)
#endif
	}

	// MARK: helpers
	private func computeAspectRatio() -> CGFloat {
		if editableDevice.device.type == .rack {
			let w: CGFloat = DeviceMetrics.bodyInches(for: editableDevice.device.rackWidth) // 19 / 8.5 / 5.5
			let h: CGFloat = 1.75 * CGFloat(editableDevice.device.rackUnits ?? 1)
			return w / h
		} else {
			let w: CGFloat = 1.5 * CGFloat(editableDevice.device.slotWidth ?? 1)
			let h: CGFloat = 5.25
			return w / h
		}
	}

	private var selectedControlBinding: Binding<Control>? {
		guard let id = selectedControlId,
			  let idx = editableDevice.device.controls.firstIndex(where: { $0.id == id }) else { return nil }
		return $editableDevice.device.controls[idx]
	}
	
	private func defaultRect(around c: Control) -> CGRect {
		let s = ImageRegion.defaultSize
		var r = CGRect(x: max(0, c.x - s * 0.5),
					   y: max(0, c.y - s * 0.5),
					   width: s, height: s)
		r.origin.x = min(r.origin.x, 1 - r.size.width)
		r.origin.y = min(r.origin.y, 1 - r.size.height)
		return r
	}

	private func updateRegionRect(of sel: Binding<Control>, to new: CGRect, idx: Int = 0) {
		var r = new
		// min size
		r.size.width  = max(minRegion, r.size.width)
		r.size.height = max(minRegion, r.size.height)
		// clamp to canvas 0…1
		r.origin.x = min(max(r.origin.x, 0), 1 - r.size.width)
		r.origin.y = min(max(r.origin.y, 0), 1 - r.size.height)
		
		var c = sel.wrappedValue
		if c.regions.indices.contains(idx) {
			// NO aspect enforcement here
			c.regions[idx].rect = r
		} else {
			let fallbackShape = c.regions.first?.shape ?? .circle
			c.regions.append(ImageRegion(rect: r, mapping: nil, shape: fallbackShape))
		}
		sel.wrappedValue = c
	}


	private func snap(_ v: CGFloat) -> CGFloat {
		(v.clamped(to: 0...1) / gridStep).rounded() * gridStep
	}
}
